package com.mod.htgt6.common.item;
import com.mod.htgt6.HTGT6;
import com.mod.htgt6.common.handler.ModTab;
import net.minecraft.item.Item;
public class NovaCrystallDust extends Item {
    public NovaCrystallDust() {
        setUnlocalizedName("NovaCrystallDust");
        setTextureName(HTGT6.MOD_ID + ":NovaCrystalDust");
        setMaxStackSize(64);
        setCreativeTab(ModTab.INSTANCE);
    }
}
