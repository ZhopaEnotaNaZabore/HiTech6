package com.mod.htgt6.common.item;

import com.mod.htgt6.HTGT6;
import net.minecraft.item.Item;

public class ModLogo extends Item {
    public ModLogo () {
        setUnlocalizedName("ModLogo");
        setTextureName(HTGT6.MOD_ID+ ":logo");
    }
}
